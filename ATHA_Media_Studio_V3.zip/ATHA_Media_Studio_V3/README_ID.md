# ATHA Media Studio V3

Kumpulan tools media, teks, dan utilitas dalam satu website. Bisa di-deploy ke **Vercel** atau **Pterodactyl/VPS**.

## Tools
| Kategori | Tools |
|---|---|
| Downloader | Universal Downloader (lewat provider API), TikTok Quick Mode |
| Foto | Photo Enhancer, Kompresor & Konverter, Rotasi & Flip |
| Video | Video Studio (filter warna, trim, kecepatan, hapus audio, ambil frame, ekspor WebM) |
| Teks | Penghitung Kata, Konverter Huruf, JSON Formatter, Base64 |
| Utilitas | QR Code Generator, Generator Password, Konverter Warna, Pomodoro Timer |

Sebagian besar tools berjalan sepenuhnya di browser, jadi file tidak dikirim ke server.

## Deploy ke Vercel (disarankan)
1. Upload folder ini ke GitHub, lalu klik **Add New → Project** di vercel.com dan impor repository tersebut.
2. Framework Preset: **Other**. Build Command dan Install Command dikosongkan. Output Directory otomatis `public` dari `vercel.json`.
3. Di **Settings → Environment Variables**, tambahkan:
   - `DOWNLOAD_API_URL` = endpoint provider downloader kamu
   - `DOWNLOAD_API_KEY` = API key provider (opsional)
4. Klik **Deploy**. Fungsi `/api/download` berjalan otomatis sebagai Vercel Function.

Alternatif: `npm i -g vercel` lalu jalankan `vercel` di folder ini.

## Deploy ke Pterodactyl / VPS
1. Buat server Node.js 20+, upload isi folder, lalu jalankan `npm install`.
2. Salin `.env.example` menjadi `.env` dan isi `DOWNLOAD_API_URL`.
3. Startup command: `npm start`. Port mengikuti `PORT` dari panel (jangan di-hardcode).
4. Pasang HTTPS lewat reverse proxy sebelum membuka akses publik.

## Konfigurasi downloader
Endpoint `/api/download` hanya meneruskan tautan ke provider. Gunakan hanya untuk konten yang kamu miliki atau punya izin untuk mengunduhnya. Jangan dipakai untuk melewati konten privat, DRM, atau pembatasan akses.

## Catatan
- Profil disimpan di browser masing-masing (localStorage). Tidak ada akun dan tidak ada data pengguna di server.
- Global Chat dihapus pada V3 karena membutuhkan server WebSocket yang persisten.
- Mode TikTok Quick memakai API pihak ketiga yang bisa berubah atau dibatasi sewaktu-waktu.
- Photo Enhancer memakai pembesaran dan penajaman dasar, bukan AI super-resolution.
