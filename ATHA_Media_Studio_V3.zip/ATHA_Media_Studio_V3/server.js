// Server untuk Pterodactyl / VPS. Di Vercel, file ini tidak dipakai (Vercel memakai public/ + api/).
require('dotenv').config();
const path = require('path');
const express = require('express');
const rateLimit = require('express-rate-limit');
const download = require('./api/download');

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.disable('x-powered-by');
app.use(express.json({ limit: '16kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }));
app.post('/api/download', download);
app.get('/api/health', (req, res) => res.json({ ok: true, service: 'ATHA Media Studio' }));
app.use(express.static(path.join(__dirname, 'public'), { dotfiles: 'ignore' }));
app.use((err, req, res, next) => {
  res.status(err.status || 500).json({ error: err.status === 400 ? 'Body JSON tidak valid' : 'Terjadi kesalahan server' });
});

app.listen(PORT, '0.0.0.0', () => console.log(`ATHA Media Studio running on ${PORT}`));
