// Handler downloader. Dipakai oleh Vercel (serverless) dan server.js (Pterodactyl/VPS).
// Tidak menyimpan apa pun; hanya meneruskan tautan ke provider yang kamu konfigurasi.

const TIMEOUT_MS = 25_000;
const MAX_URL_LENGTH = 2048;

function isHttpUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Gunakan metode POST' });
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body || '{}'); }
    catch { return res.status(400).json({ error: 'Body JSON tidak valid' }); }
  }

  const url = String(body?.url || '').trim();
  if (!url || url.length > MAX_URL_LENGTH || !isHttpUrl(url)) {
    return res.status(400).json({ error: 'URL tidak valid' });
  }

  const endpoint = process.env.DOWNLOAD_API_URL;
  if (!endpoint) {
    return res.status(503).json({
      error: 'Downloader belum dikonfigurasi. Isi DOWNLOAD_API_URL di Environment Variables (Vercel) atau file .env.'
    });
  }

  try {
    const headers = { 'Content-Type': 'application/json', Accept: 'application/json' };
    if (process.env.DOWNLOAD_API_KEY) headers.Authorization = 'Bearer ' + process.env.DOWNLOAD_API_KEY;

    const upstream = await fetch(endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify({ url }),
      signal: AbortSignal.timeout(TIMEOUT_MS)
    });
    if (!upstream.ok) return res.status(502).json({ error: 'Provider downloader menolak permintaan' });

    const data = await upstream.json();
    const links = (Array.isArray(data?.links) ? data.links : [])
      .filter(l => l && isHttpUrl(l.url))
      .slice(0, 30)
      .map(l => ({ label: String(l.label || l.quality || 'Download').slice(0, 60), url: l.url }));

    return res.status(200).json({ title: String(data?.title || 'Media').slice(0, 200), links });
  } catch {
    return res.status(502).json({ error: 'Provider downloader tidak dapat dihubungi' });
  }
};
