/* ============================================================
   ATHA Media Studio — router, beranda, dan profil lokal
   ============================================================ */

// EDIT DI SINI: profil creator yang tampil di beranda.
const CREATOR = {
  name: 'ATHA • Creator',
  bio: 'Media tools, creativity, and digital experiences — all in one place.',
  photo: '/assets/atha-tiktok-logo.png', // ganti dengan direct image URL (mis. link Catbox)
  links: [
    // { label: 'Instagram', url: 'https://instagram.com/username' },
    // { label: 'WhatsApp', url: 'https://wa.me/628xxxxxxxxxx' },
  ]
};

const CAT_ORDER = ['Downloader', 'Foto', 'Video', 'Teks', 'Utilitas'];
const PROFILE_KEY = 'atha_profile';
const $ = (s, root = document) => root.querySelector(s);

/* ---------- profil (localStorage, hanya di browser ini) ---------- */
function getProfile() {
  try { return JSON.parse(localStorage.getItem(PROFILE_KEY)) || {}; } catch { return {}; }
}
function setProfile(p) {
  try { localStorage.setItem(PROFILE_KEY, JSON.stringify(p)); return true; } catch { return false; }
}
function avatarOf(p) { return p.avatar || CREATOR.photo; }

function paintHeader() {
  const p = getProfile();
  $('#meAvatar').src = avatarOf(p);
  $('#meName').textContent = p.name || 'Tamu';
}

// Perkecil gambar agar muat di localStorage (≈ 256 px, JPEG).
function shrinkImage(file, max) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const s = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight));
      const c = document.createElement('canvas');
      c.width = Math.round(im.naturalWidth * s); c.height = Math.round(im.naturalHeight * s);
      const cx = c.getContext('2d');
      cx.fillStyle = '#ffffff'; cx.fillRect(0, 0, c.width, c.height);
      cx.drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', 0.88));
    };
    im.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Gambar tidak bisa dibaca')); };
    im.src = url;
  });
}

function renderProfile() {
  const p = getProfile();
  $('#profileBody').innerHTML = `
    <div class="tool-head"><span class="ico">👤</span><div><h2>Profil saya</h2>
      <p class="desc">Disimpan hanya di browser ini. Tidak dikirim ke server.</p></div></div>
    <div class="avatar-edit">
      <img id="pAvatar" src="${avatarOf(p)}" alt="Foto profil">
      <div><input type="file" id="pFile" accept="image/png,image/jpeg,image/webp,image/gif">
        <p class="desc">PNG, JPG, WEBP, atau GIF (maks. 3 MB, otomatis diperkecil)</p></div>
    </div>
    <label class="field">Nama tampilan<input class="input" id="pName" maxlength="28" placeholder="Nama kamu" value="${p.name ? p.name.replace(/"/g, '&quot;') : ''}"></label>
    <label class="field">Bio<textarea class="input" id="pBio" maxlength="160" rows="3" placeholder="Ceritakan sedikit tentang dirimu">${p.bio ? p.bio.replace(/</g, '&lt;') : ''}</textarea></label>
    <div class="actions"><button class="btn" id="pSave">Simpan profil</button><button class="btn secondary" id="pReset">Hapus profil</button></div>
    <div class="result" id="pStatus">Profil dimuat.</div>`;

  let pendingAvatar = null;
  const status = $('#pStatus');

  $('#pFile').addEventListener('change', async e => {
    const f = e.target.files[0];
    if (!f) return;
    if (!/^image\/(png|jpeg|webp|gif)$/.test(f.type) || f.size > 3 * 1024 * 1024) {
      status.textContent = 'Pilih gambar PNG/JPG/WEBP/GIF maksimal 3 MB.'; return;
    }
    try {
      pendingAvatar = await shrinkImage(f, 256);
      $('#pAvatar').src = pendingAvatar;
    } catch (err) { status.textContent = '❌ ' + err.message; }
  });

  $('#pSave').addEventListener('click', () => {
    const name = $('#pName').value.trim();
    if (name.length < 2) { status.textContent = 'Nama minimal 2 karakter.'; return; }
    const saved = setProfile({
      name,
      bio: $('#pBio').value.trim(),
      avatar: pendingAvatar || p.avatar || ''
    });
    status.textContent = saved ? '✅ Profil tersimpan.' : '❌ Gagal menyimpan. Penyimpanan browser penuh atau diblokir.';
    paintHeader();
  });

  $('#pReset').addEventListener('click', () => {
    localStorage.removeItem(PROFILE_KEY);
    renderProfile();
    paintHeader();
  });
}

/* ---------- beranda ---------- */
function renderHome() {
  const creatorLinks = CREATOR.links.map(l => {
    const href = httpUrl(l.url);
    return href ? `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">${esc(l.label || 'Link')}</a>` : '';
  }).join('');

  $('#view-home').innerHTML = `
    <div class="hero">
      <h1>ATHA <span>MEDIA STUDIO</span></h1>
      <p>Download • Enhance • Create — ${ATHA_TOOLS.length} tools media, teks, dan utilitas dalam satu tempat.</p>
    </div>
    <section class="creator" aria-label="Profil creator">
      <img src="${esc(CREATOR.photo)}" alt="Foto creator">
      <div class="creator-copy">
        <div class="kicker">WELCOME TO MY WEBSITE</div>
        <div class="creator-name">${esc(CREATOR.name)}</div>
        <div class="creator-bio">${esc(CREATOR.bio)}</div>
        ${creatorLinks ? `<div class="creator-links">${creatorLinks}</div>` : ''}
      </div>
    </section>
    <input class="input search" id="search" type="search" placeholder="Cari tools… (mis. video, kompres, password)">
    <div id="toolList"></div>`;

  $('#search').addEventListener('input', e => renderList(e.target.value));
  renderList('');
}

function renderList(query) {
  const term = query.trim().toLowerCase();
  const list = ATHA_TOOLS.filter(t => !term || `${t.title} ${t.desc} ${t.cat}`.toLowerCase().includes(term));
  if (!list.length) { $('#toolList').innerHTML = '<p class="desc center">Tidak ada tools yang cocok.</p>'; return; }
  $('#toolList').innerHTML = CAT_ORDER.map(cat => {
    const items = list.filter(t => t.cat === cat);
    if (!items.length) return '';
    return `<h2 class="cat-title">${esc(cat)}</h2><div class="grid">${items.map(t => `
      <a class="tool-card" href="#${esc(t.id)}">
        <span class="ico">${t.icon}</span><b>${esc(t.title)}</b><small>${esc(t.desc)}</small>
      </a>`).join('')}</div>`;
  }).join('');
}

/* ---------- router ---------- */
let cleanup = null;

function show(name) {
  ['home', 'tool', 'profile'].forEach(n => $('#view-' + n).classList.toggle('hidden', n !== name));
}

function route() {
  if (cleanup) { try { cleanup(); } catch {} cleanup = null; }
  const id = decodeURIComponent(location.hash.slice(1));
  window.scrollTo(0, 0);

  if (id === 'profil') {
    show('profile'); renderProfile();
    document.title = 'Profil — ATHA Media Studio';
    return;
  }

  const tool = ATHA_TOOLS.find(t => t.id === id);
  if (tool) {
    show('tool');
    $('#toolHead').innerHTML = `<span class="ico">${tool.icon}</span>
      <div><div class="desc" style="margin:0;letter-spacing:2px;font-size:11px;text-transform:uppercase">${esc(tool.cat)}</div>
      <h2>${esc(tool.title)}</h2><p class="desc">${esc(tool.desc)}</p></div>`;
    // Ganti container agar listener dari alat sebelumnya tidak ikut terbawa.
    const oldBody = $('#toolBody');
    const body = oldBody.cloneNode(false);
    oldBody.replaceWith(body);
    const c = tool.render(body);
    if (typeof c === 'function') cleanup = c;
    document.title = tool.title + ' — ATHA Media Studio';
    return;
  }

  show('home'); renderHome();
  document.title = 'ATHA Media Studio';
}

paintHeader();
window.addEventListener('hashchange', route);
route();
