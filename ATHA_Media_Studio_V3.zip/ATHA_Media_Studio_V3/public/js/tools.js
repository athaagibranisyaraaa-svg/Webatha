/* ============================================================
   ATHA Media Studio — kumpulan tools
   Kebanyakan tools berjalan sepenuhnya di browser.
   Downloader memanggil /api/download (Vercel Function / server.js).
   ============================================================ */

const ATHA_TOOLS = [];
const reg = t => ATHA_TOOLS.push(t);

/* ---------- helper umum ---------- */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const httpUrl = v => { try { const u = new URL(v); return (u.protocol === 'http:' || u.protocol === 'https:') ? u.href : ''; } catch { return ''; } };
const fmtBytes = n => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(2) + ' MB';
const fmtTime = s => { s = Math.max(0, Math.floor(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const fmtNum = n => n == null ? '—' : Number(n).toLocaleString('id-ID');
const extOf = mime => mime.split('/')[1].replace('jpeg', 'jpg');

function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function flash(btn, msg) {
  if (!btn) return;
  if (!btn.dataset.label) btn.dataset.label = btn.textContent;
  btn.textContent = msg;
  clearTimeout(btn._t);
  btn._t = setTimeout(() => { btn.textContent = btn.dataset.label; }, 1400);
}

async function copyText(text, btn) {
  try { await navigator.clipboard.writeText(text); flash(btn, 'Tersalin ✓'); }
  catch { flash(btn, 'Gagal menyalin'); }
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error('Gagal memuat library dari CDN'));
    document.head.appendChild(s);
  });
}

function mkBtn(text, cls = 'btn') {
  const b = document.createElement('button');
  b.type = 'button'; b.className = cls; b.textContent = text;
  return b;
}

// Area unggah: klik atau seret file ke sini.
function dropzone(accept, hint, onFile) {
  const label = document.createElement('label');
  label.className = 'drop';
  label.innerHTML = `<input type="file" accept="${esc(accept)}" hidden>
    <span class="drop-icon">⬆</span><b>Pilih atau seret file ke sini</b><p>${esc(hint)}</p>`;
  const input = label.querySelector('input');
  input.addEventListener('change', () => { const f = input.files[0]; input.value = ''; if (f) onFile(f); });
  label.addEventListener('dragover', e => { e.preventDefault(); label.classList.add('drag'); });
  label.addEventListener('dragleave', () => label.classList.remove('drag'));
  label.addEventListener('drop', e => {
    e.preventDefault(); label.classList.remove('drag');
    const f = e.dataTransfer.files[0]; if (f) onFile(f);
  });
  return label;
}

// Slider dengan label nilai. onInput dipanggil saat pengguna menggeser.
function slider(label, min, max, value, fmt = v => v, onInput) {
  const wrap = document.createElement('div');
  wrap.className = 'control';
  wrap.innerHTML = `<label>${esc(label)} <span class="val"></span></label><input type="range" min="${min}" max="${max}" value="${value}">`;
  const input = wrap.querySelector('input'), out = wrap.querySelector('.val');
  const show = () => { out.textContent = fmt(Number(input.value)); };
  input.addEventListener('input', () => { show(); if (onInput) onInput(Number(input.value)); });
  show();
  wrap.input = input;
  return wrap;
}

// Dropdown dengan label. options: [[nilai, teks], ...]
function select(label, options, value) {
  const wrap = document.createElement('div');
  wrap.className = 'control';
  wrap.innerHTML = `<label>${esc(label)}</label><select class="input">${options.map(([v, t]) =>
    `<option value="${esc(v)}" ${v === value ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>`;
  wrap.select = wrap.querySelector('select');
  return wrap;
}

function numField(label, value = 0) {
  const wrap = document.createElement('div');
  wrap.className = 'control';
  wrap.innerHTML = `<label>${esc(label)}</label><input class="input sm" type="number" min="0" step="0.1" value="${value}">`;
  wrap.input = wrap.querySelector('input');
  return wrap;
}

function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.frequency.value = 880;
    g.gain.setValueAtTime(0.2, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);
    o.start(); o.stop(ctx.currentTime + 1.2);
  } catch {}
}

/* ============================================================
   DOWNLOADER
   ============================================================ */
reg({
  id: 'downloader', cat: 'Downloader', icon: '🌐', title: 'Universal Downloader',
  desc: 'Tempel tautan media dari platform yang didukung penyedia API kamu.',
  render(root) {
    root.innerHTML = `
      <p class="desc">Server meneruskan tautan ke penyedia downloader yang dikonfigurasi (DOWNLOAD_API_URL). Gunakan hanya untuk konten milikmu atau yang kamu punya izin untuk mengunduhnya.</p>
      <div class="row"><input class="input" id="dlUrl" placeholder="https://..."><button class="btn" id="dlGo">Cari media</button></div>
      <div class="result hidden" id="dlOut"></div>`;
    const $ = s => root.querySelector(s);
    const go = async () => {
      const url = $('#dlUrl').value.trim();
      const out = $('#dlOut'), goBtn = $('#dlGo');
      out.classList.remove('hidden');
      if (!httpUrl(url)) { out.innerHTML = '<span class="err">Masukkan tautan http(s) yang valid.</span>'; return; }
      goBtn.disabled = true;
      out.innerHTML = '<div class="pulse">⏳ Memproses tautan...</div>';
      try {
        const r = await fetch('/api/download', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url })
        });
        const data = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(data.error || 'Permintaan gagal');
        const links = (Array.isArray(data.links) ? data.links : [])
          .map(l => ({ label: l.label || 'Download', url: httpUrl(l.url) })).filter(l => l.url);
        out.innerHTML = `<strong class="res-title">${esc(data.title || 'Media ditemukan')}</strong>` +
          (links.length
            ? links.map(l => `<div class="opt"><strong>${esc(l.label)}</strong><a class="btn sm" href="${esc(l.url)}" target="_blank" rel="noopener noreferrer">Unduh</a></div>`).join('')
            : '<p class="desc">Penyedia tidak mengembalikan tautan unduhan.</p>');
      } catch (e) {
        out.innerHTML = `<span class="err">❌ ${esc(e.message)}</span>`;
      } finally { goBtn.disabled = false; }
    };
    $('#dlGo').addEventListener('click', go);
    $('#dlUrl').addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  }
});

const TT_APIS = [
  u => `https://tikwm.com/api/?url=${encodeURIComponent(u)}`,
  u => `https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(u)}`
];

async function ttFetch(url) {
  const abs = v => { try { return v ? new URL(String(v), 'https://tikwm.com').href : ''; } catch { return ''; } };
  let lastErr;
  for (const mk of TT_APIS) {
    try {
      const r = await fetch(mk(url));
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const json = await r.json();
      const d = json.data || json, a = d.author || {};
      const video = abs(d.play || d.hdplay || d.video?.noWatermark || d.video?.url || json.video || '');
      const music = abs(d.music || d.music_info?.play || d.audio || json.music || '');
      const images = (Array.isArray(d.images) ? d.images : []).map(abs).filter(Boolean);
      if (!video && !music && !images.length) throw new Error('Data media tidak ditemukan');
      return {
        title: d.title || d.desc || 'Video TikTok',
        cover: abs(d.cover || d.origin_cover || ''),
        author: {
          name: a.nickname || a.name || 'Kreator TikTok',
          username: a.unique_id || a.uniqueId || a.username || '',
          avatar: abs(a.avatar || a.avatar_thumb || '')
        },
        stats: {
          views: d.play_count ?? d.statistics?.playCount,
          likes: d.digg_count ?? d.statistics?.diggCount,
          comments: d.comment_count ?? d.statistics?.commentCount,
          shares: d.share_count ?? d.statistics?.shareCount
        },
        duration: d.duration || 0,
        video, hdVideo: abs(d.hdplay || ''), watermark: abs(d.wmplay || ''), music, images
      };
    } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error('Semua server gagal');
}

reg({
  id: 'tiktok', cat: 'Downloader', icon: '🎵', title: 'TikTok Quick Mode',
  desc: 'Ambil video tanpa watermark, audio, dan foto slideshow dari tautan TikTok.',
  render(root) {
    root.innerHTML = `
      <div class="features"><span>✓ Tanpa watermark</span><span>✓ Audio</span><span>✓ Foto slideshow</span></div>
      <p class="desc">Memakai API publik pihak ketiga yang bisa berubah atau membatasi akses sewaktu-waktu.</p>
      <div class="row"><input class="input" id="ttUrl" placeholder="Tempel tautan TikTok..."><button class="btn" id="ttGo">Ambil</button></div>
      <div class="result hidden" id="ttOut"></div>`;
    const $ = s => root.querySelector(s);
    const go = async () => {
      const url = $('#ttUrl').value.trim();
      const out = $('#ttOut'), goBtn = $('#ttGo');
      out.classList.remove('hidden');
      if (!/^https?:\/\/(?:www\.|vm\.|vt\.)?tiktok\.com\//i.test(url)) {
        out.innerHTML = '<span class="err">❌ Masukkan tautan TikTok yang valid.</span>'; return;
      }
      goBtn.disabled = true;
      out.innerHTML = '<div class="pulse">⏳ Mengambil informasi video dan kreator...</div>';
      try {
        const d = await ttFetch(url);
        const s = d.stats;
        const opts = [
          ['🎬 Video tanpa watermark', 'MP4 • kualitas sumber', d.video, 'ATHA-VIDEO.mp4'],
          ['💎 Video HD', 'MP4 • jika tersedia', d.hdVideo, 'ATHA-VIDEO-HD.mp4'],
          ['🎥 Video dengan watermark', 'MP4 • jika tersedia', d.watermark, 'ATHA-WATERMARK.mp4'],
          ['🎵 Audio', 'Audio dari sumber', d.music, 'ATHA-AUDIO'],
          ...d.images.map((u, i) => [`🖼️ Foto ${i + 1}`, 'Foto slideshow', u, `ATHA-PHOTO-${i + 1}.jpg`])
        ].filter(o => o[2]);
        out.innerHTML = `
          <div class="creator-row">
            ${d.author.avatar ? `<img src="${esc(d.author.avatar)}" alt="">` : ''}
            <div><b>${esc(d.author.name)}</b><div class="desc" style="margin:0">${d.author.username ? '@' + esc(d.author.username) : 'TikTok Creator'}</div></div>
          </div>
          ${d.cover ? `<img class="cover" src="${esc(d.cover)}" alt="Thumbnail">` : ''}
          <p class="caption">${esc(d.title)}</p>
          <div class="features">
            <span>👁 ${fmtNum(s.views)}</span><span>❤️ ${fmtNum(s.likes)}</span><span>💬 ${fmtNum(s.comments)}</span>
            <span>↗ ${fmtNum(s.shares)}</span><span>⏱ ${d.duration || '—'}s</span>
          </div>
          ${opts.length ? opts.map(([name, desc, u]) =>
            `<div class="opt"><div><strong>${esc(name)}</strong><small>${esc(desc)}</small></div><a class="btn sm" href="${esc(u)}" target="_blank" rel="noopener noreferrer">Unduh</a></div>`).join('')
            : '<p class="desc">Opsi unduhan tidak tersedia dari API.</p>'}`;
      } catch (e) {
        out.innerHTML = `<span class="err">❌ Gagal mengambil data. ${esc(e.message)}</span>`;
      } finally { goBtn.disabled = false; }
    };
    $('#ttGo').addEventListener('click', go);
    $('#ttUrl').addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  }
});

/* ============================================================
   FOTO
   ============================================================ */
reg({
  id: 'photo-enhancer', cat: 'Foto', icon: '🖼️', title: 'Photo Enhancer',
  desc: 'Perbesar dimensi foto dan atur cahaya, kontras, serta ketajaman.',
  render(root) {
    let objUrl = null, result = null, ext = 'png';
    root.innerHTML = '<div class="work hidden"></div>';
    const work = root.querySelector('.work');

    const img = new Image();
    img.alt = 'Pratinjau';
    const preview = document.createElement('div');
    preview.className = 'preview'; preview.append(img);

    const applyPreview = () => { img.style.filter = `brightness(${bright.input.value}%) contrast(${contrast.input.value}%)`; };
    const scale = select('Resolusi pembesaran', [['1', 'Original'], ['2', '2×'], ['4', '4×']], '2');
    const format = select('Format hasil', [['image/png', 'PNG'], ['image/jpeg', 'JPG'], ['image/webp', 'WEBP']], 'image/png');
    const bright = slider('Brightness', 50, 150, 100, v => v + '%', applyPreview);
    const contrast = slider('Contrast', 50, 150, 100, v => v + '%', applyPreview);
    const sharp = slider('Ketajaman', 0, 100, 30, v => v + '%');
    const grid = document.createElement('div'); grid.className = 'grid2';
    grid.append(scale, format, bright, contrast, sharp);

    const runBtn = mkBtn('✨ Proses foto');
    const saveBtn = mkBtn('⬇ Simpan', 'btn secondary'); saveBtn.disabled = true;
    const actions = document.createElement('div'); actions.className = 'actions'; actions.append(runBtn, saveBtn);
    const status = document.createElement('div'); status.className = 'result';
    status.textContent = 'Foto belum diproses.';
    work.append(preview, grid, actions, status);

    root.prepend(dropzone('image/*', 'JPG, PNG, WEBP', file => {
      if (!file.type.startsWith('image/')) { status.textContent = 'Pilih file gambar yang valid.'; return; }
      if (objUrl) URL.revokeObjectURL(objUrl);
      objUrl = URL.createObjectURL(file);
      img.src = objUrl; applyPreview();
      work.classList.remove('hidden');
      result = null; saveBtn.disabled = true;
      status.textContent = 'Foto berhasil dimuat.';
    }));

    runBtn.addEventListener('click', () => {
      if (!img.naturalWidth) return;
      const s = Number(scale.select.value);
      const w = img.naturalWidth * s, h = img.naturalHeight * s;
      if (w * h > 25e6) { status.textContent = '❌ Ukuran hasil terlalu besar untuk browser. Pilih skala lebih kecil.'; return; }

      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      const cx = c.getContext('2d', { willReadFrequently: true });
      cx.imageSmoothingEnabled = true; cx.imageSmoothingQuality = 'high';
      cx.filter = `brightness(${bright.input.value}%) contrast(${contrast.input.value}%)`;
      cx.drawImage(img, 0, 0, w, h);
      cx.filter = 'none';

      const amount = Number(sharp.input.value) / 100;
      if (amount > 0 && w * h < 8e6) {
        const im = cx.getImageData(0, 0, w, h), src = new Uint8ClampedArray(im.data);
        for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
          const i = (y * w + x) * 4;
          for (let k = 0; k < 3; k++) {
            const n = src[i - 4 + k] + src[i + 4 + k] + src[i - w * 4 + k] + src[i + w * 4 + k];
            im.data[i + k] = src[i + k] + (src[i + k] * 4 - n) * amount * 0.15;
          }
        }
        cx.putImageData(im, 0, 0);
      }

      const mime = format.select.value;
      ext = extOf(mime);
      status.textContent = '⏳ Memproses...';
      c.toBlob(blob => {
        if (!blob) { status.textContent = '❌ Format ini tidak didukung browser kamu.'; return; }
        result = blob;
        saveBtn.disabled = false;
        status.textContent = `✅ Selesai • ${w} × ${h} px • ${fmtBytes(blob.size)}. Ini pembesaran dimensi dan penajaman dasar, bukan AI super-resolution.`;
      }, mime, mime === 'image/png' ? undefined : 0.94);
    });

    saveBtn.addEventListener('click', () => { if (result) saveBlob(result, 'ATHA-HD.' + ext); });

    return () => { if (objUrl) URL.revokeObjectURL(objUrl); };
  }
});

reg({
  id: 'image-compress', cat: 'Foto', icon: '🗜️', title: 'Kompresor & Konverter',
  desc: 'Kecilkan ukuran file, ubah format JPG/PNG/WEBP, dan batasi lebar gambar.',
  render(root) {
    let file = null, objUrl = null, out = null, outUrl = null;
    root.innerHTML = '<div class="work hidden"></div>';
    const work = root.querySelector('.work');

    const img = new Image();
    img.alt = 'Pratinjau';
    const preview = document.createElement('div'); preview.className = 'preview'; preview.append(img);

    const format = select('Format output', [['image/webp', 'WEBP (paling kecil)'], ['image/jpeg', 'JPG'], ['image/png', 'PNG (tanpa kompresi lossy)']], 'image/webp');
    const maxW = select('Lebar maksimal', [['0', 'Tidak diubah'], ['3840', '4K (3840 px)'], ['1920', 'Full HD (1920 px)'], ['1280', 'HD (1280 px)'], ['800', 'Kecil (800 px)']], '1920');
    const quality = slider('Kualitas', 10, 100, 80, v => v + '%');
    const grid = document.createElement('div'); grid.className = 'grid2';
    grid.append(format, maxW, quality);

    const stats = document.createElement('div'); stats.className = 'stats';
    stats.innerHTML = '<div><small>Asli</small><b data-o>—</b></div><div><small>Hasil</small><b data-n>—</b></div><div><small>Hemat</small><b data-s>—</b></div>';
    const runBtn = mkBtn('⚡ Kompres & konversi');
    const saveBtn = mkBtn('⬇ Unduh hasil', 'btn secondary'); saveBtn.disabled = true;
    const actions = document.createElement('div'); actions.className = 'actions'; actions.append(runBtn, saveBtn);
    const status = document.createElement('div'); status.className = 'result';
    work.append(preview, grid, stats, actions, status);

    root.prepend(dropzone('image/*', 'JPG, PNG, WEBP, GIF', f => {
      if (!f.type.startsWith('image/')) { status.textContent = 'Pilih file gambar yang valid.'; return; }
      file = f;
      if (objUrl) URL.revokeObjectURL(objUrl);
      objUrl = URL.createObjectURL(f); img.src = objUrl;
      out = null; saveBtn.disabled = true;
      stats.querySelector('[data-o]').textContent = fmtBytes(f.size);
      stats.querySelector('[data-n]').textContent = '—';
      stats.querySelector('[data-s]').textContent = '—';
      status.textContent = 'Gambar dimuat. Pilih pengaturan lalu tekan Kompres.';
      work.classList.remove('hidden');
    }));

    runBtn.addEventListener('click', async () => {
      if (!img.naturalWidth || !file) return;
      runBtn.disabled = true; status.textContent = '⏳ Memproses...';
      try {
        const limit = Number(maxW.select.value);
        const scale = limit && img.naturalWidth > limit ? limit / img.naturalWidth : 1;
        const w = Math.round(img.naturalWidth * scale), h = Math.round(img.naturalHeight * scale);
        const c = document.createElement('canvas'); c.width = w; c.height = h;
        const cx = c.getContext('2d');
        const mime = format.select.value;
        if (mime === 'image/jpeg') { cx.fillStyle = '#ffffff'; cx.fillRect(0, 0, w, h); }
        cx.imageSmoothingQuality = 'high';
        cx.drawImage(img, 0, 0, w, h);
        const blob = await new Promise((res, rej) => c.toBlob(
          b => b ? res(b) : rej(new Error('Format ini tidak didukung browser kamu')),
          mime, mime === 'image/png' ? undefined : Number(quality.input.value) / 100
        ));
        out = { blob, ext: extOf(mime) };
        if (outUrl) URL.revokeObjectURL(outUrl);
        outUrl = URL.createObjectURL(blob);
        const saving = 1 - blob.size / file.size;
        stats.querySelector('[data-n]').textContent = fmtBytes(blob.size);
        stats.querySelector('[data-s]').textContent = saving >= 0
          ? Math.round(saving * 100) + '%'
          : '+' + Math.round(-saving * 100) + '% (lebih besar)';
        saveBtn.disabled = false;
        status.textContent = `✅ Selesai • ${w} × ${h} px • format ${out.ext.toUpperCase()}`;
      } catch (e) {
        status.textContent = '❌ ' + e.message;
      } finally { runBtn.disabled = false; }
    });

    saveBtn.addEventListener('click', () => { if (out) saveBlob(out.blob, 'ATHA-COMPRESSED.' + out.ext); });

    return () => { if (objUrl) URL.revokeObjectURL(objUrl); if (outUrl) URL.revokeObjectURL(outUrl); };
  }
});

reg({
  id: 'image-transform', cat: 'Foto', icon: '🔄', title: 'Rotasi & Flip',
  desc: 'Putar dan balik gambar, lalu simpan dalam format pilihanmu.',
  render(root) {
    let img = null, objUrl = null, rot = 0, fx = false, fy = false;
    root.innerHTML = '<div class="work hidden"></div>';
    const work = root.querySelector('.work');

    const canvas = document.createElement('canvas');
    const preview = document.createElement('div'); preview.className = 'preview'; preview.append(canvas);

    const draw = () => {
      if (!img) return;
      const swap = rot % 180 !== 0;
      canvas.width = swap ? img.naturalHeight : img.naturalWidth;
      canvas.height = swap ? img.naturalWidth : img.naturalHeight;
      const cx = canvas.getContext('2d');
      cx.clearRect(0, 0, canvas.width, canvas.height);
      cx.save();
      cx.translate(canvas.width / 2, canvas.height / 2);
      cx.rotate(rot * Math.PI / 180);
      cx.scale(fx ? -1 : 1, fy ? -1 : 1);
      cx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
      cx.restore();
    };

    const toolbar = document.createElement('div'); toolbar.className = 'actions';
    [
      ['↺ 90°', () => { rot = (rot + 270) % 360; }],
      ['↻ 90°', () => { rot = (rot + 90) % 360; }],
      ['⇋ Flip H', () => { fx = !fx; }],
      ['⇵ Flip V', () => { fy = !fy; }],
      ['Reset', () => { rot = 0; fx = false; fy = false; }]
    ].forEach(([label, fn]) => {
      const b = mkBtn(label, 'btn secondary sm');
      b.addEventListener('click', () => { fn(); draw(); });
      toolbar.append(b);
    });

    const format = select('Format simpan', [['image/png', 'PNG'], ['image/jpeg', 'JPG'], ['image/webp', 'WEBP']], 'image/png');
    const saveBtn = mkBtn('⬇ Simpan hasil');
    const actions = document.createElement('div'); actions.className = 'actions'; actions.append(saveBtn);
    work.append(preview, toolbar, format, actions);

    root.prepend(dropzone('image/*', 'JPG, PNG, WEBP, GIF', file => {
      if (!file.type.startsWith('image/')) return;
      if (objUrl) URL.revokeObjectURL(objUrl);
      objUrl = URL.createObjectURL(file);
      const im = new Image();
      im.onload = () => { img = im; rot = 0; fx = false; fy = false; draw(); work.classList.remove('hidden'); };
      im.src = objUrl;
    }));

    saveBtn.addEventListener('click', () => {
      if (!img) return;
      const mime = format.select.value;
      const c = document.createElement('canvas');
      c.width = canvas.width; c.height = canvas.height;
      const cx = c.getContext('2d');
      if (mime === 'image/jpeg') { cx.fillStyle = '#ffffff'; cx.fillRect(0, 0, c.width, c.height); }
      cx.drawImage(canvas, 0, 0);
      c.toBlob(b => saveBlob(b, 'ATHA-EDIT.' + extOf(mime)), mime, mime === 'image/png' ? undefined : 0.95);
    });

    return () => { if (objUrl) URL.revokeObjectURL(objUrl); };
  }
});

/* ============================================================
   VIDEO
   ============================================================ */
reg({
  id: 'video-studio', cat: 'Video', icon: '🎬', title: 'Video Studio',
  desc: 'Filter warna, trim, kecepatan, hapus audio, ambil frame, dan ekspor WebM.',
  render(root) {
    let objUrl = null, dlUrl = null, rec = null, raf = 0;
    root.innerHTML = '<div class="work hidden"></div>';
    const work = root.querySelector('.work');

    const player = document.createElement('video');
    player.controls = true; player.playsInline = true;
    const preview = document.createElement('div'); preview.className = 'preview'; preview.append(player);

    const filterStr = () => `brightness(${bright.input.value}%) contrast(${contrast.input.value}%) saturate(${sat.input.value}%)`;
    const applyFilter = () => { player.style.filter = filterStr(); };

    const bright = slider('Brightness', 50, 150, 100, v => v + '%', applyFilter);
    const contrast = slider('Contrast', 50, 200, 100, v => v + '%', applyFilter);
    const sat = slider('Saturation', 0, 200, 100, v => v + '%', applyFilter);
    const speed = select('Kecepatan', [['0.5', '0.5×'], ['1', '1× (normal)'], ['1.5', '1.5×'], ['2', '2×']], '1');
    const grid = document.createElement('div'); grid.className = 'grid2';
    grid.append(bright, contrast, sat, speed);

    const startF = numField('Mulai (detik)', 0), endF = numField('Selesai (detik)', 0);
    const trim = document.createElement('div'); trim.className = 'grid2'; trim.append(startF, endF);

    const muteWrap = document.createElement('label'); muteWrap.className = 'check';
    muteWrap.innerHTML = '<input type="checkbox"> Hapus audio dari hasil ekspor';
    const muteCb = muteWrap.querySelector('input');

    const frameBtn = mkBtn('📸 Ambil frame', 'btn secondary');
    const exportBtn = mkBtn('✨ Ekspor WebM');
    const actions = document.createElement('div'); actions.className = 'actions'; actions.append(frameBtn, exportBtn);
    const status = document.createElement('div'); status.className = 'result';
    status.textContent = 'Video siap diedit.';
    const dl = document.createElement('a');
    dl.className = 'btn hidden'; dl.style.cssText = 'display:flex;margin-top:12px';
    dl.textContent = '⬇ Simpan video';

    work.append(preview, grid, trim, muteWrap, actions, status, dl);

    root.prepend(dropzone('video/*', 'MP4, WEBM, MOV (bergantung dukungan browser)', file => {
      if (!file.type.startsWith('video/')) { status.textContent = 'Pilih file video yang valid.'; return; }
      if (objUrl) URL.revokeObjectURL(objUrl);
      objUrl = URL.createObjectURL(file);
      player.src = objUrl;
      player.onloadedmetadata = () => {
        const d = Number.isFinite(player.duration) ? player.duration : 0;
        endF.input.value = d.toFixed(1);
        startF.input.value = '0';
        status.textContent = `Video dimuat • durasi ${fmtTime(d)}`;
      };
      applyFilter();
      dl.classList.add('hidden');
      work.classList.remove('hidden');
    }));

    frameBtn.addEventListener('click', () => {
      if (!player.videoWidth) return;
      const c = document.createElement('canvas');
      c.width = player.videoWidth; c.height = player.videoHeight;
      const cx = c.getContext('2d');
      cx.filter = filterStr();
      cx.drawImage(player, 0, 0);
      c.toBlob(b => {
        if (b) saveBlob(b, `ATHA-FRAME-${Math.floor(player.currentTime)}s.png`);
        status.textContent = '📸 Frame tersimpan.';
      }, 'image/png');
    });

    async function exportVideo() {
      if (rec) { rec.stop(); return; }
      if (!player.videoWidth) { status.textContent = 'Pilih video terlebih dahulu.'; return; }
      if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream) {
        status.textContent = 'Browser tidak mendukung ekspor. Gunakan Chrome, Edge, atau Firefox terbaru.'; return;
      }
      const s = Math.max(0, Number(startF.input.value) || 0);
      const e = Math.min(player.duration || Infinity, Number(endF.input.value) || player.duration);
      if (!(e > s)) { status.textContent = 'Waktu selesai harus lebih besar dari waktu mulai.'; return; }

      dl.classList.add('hidden');
      const canvas = document.createElement('canvas');
      canvas.width = player.videoWidth; canvas.height = player.videoHeight;
      const cx = canvas.getContext('2d');
      const stream = canvas.captureStream(30);
      if (!muteCb.checked) {
        try { player.captureStream().getAudioTracks().forEach(t => stream.addTrack(t)); } catch {}
      }

      const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ? 'video/webm;codecs=vp9' : 'video/webm';
      const chunks = [];
      rec = new MediaRecorder(stream, { mimeType: mime });
      rec.ondataavailable = ev => { if (ev.data.size) chunks.push(ev.data); };
      rec.onstop = () => {
        cancelAnimationFrame(raf);
        player.pause(); player.playbackRate = 1;
        stream.getTracks().forEach(t => t.stop());
        rec = null;
        exportBtn.textContent = '✨ Ekspor WebM';
        const blob = new Blob(chunks, { type: mime });
        if (dlUrl) URL.revokeObjectURL(dlUrl);
        dlUrl = URL.createObjectURL(blob);
        dl.href = dlUrl; dl.download = 'ATHA-VIDEO.webm';
        dl.classList.remove('hidden');
        status.textContent = `✅ Ekspor selesai • ${fmtBytes(blob.size)}. Simpan video WebM di bawah.`;
      };

      const draw = () => {
        if (!rec) return;
        cx.filter = filterStr();
        cx.drawImage(player, 0, 0, canvas.width, canvas.height);
        cx.filter = 'none';
        if (player.currentTime >= e || player.ended) { rec.stop(); return; }
        raf = requestAnimationFrame(draw);
      };

      player.pause();
      player.playbackRate = Number(speed.select.value);
      if (Math.abs(player.currentTime - s) > 0.01) {
        await new Promise(resolve => {
          player.addEventListener('seeked', resolve, { once: true });
          player.currentTime = s;
        });
      }

      exportBtn.textContent = '⏹ Hentikan';
      status.textContent = '🔄 Merekam... jangan tutup halaman.';
      rec.start(500);
      try { await player.play(); }
      catch (err) { status.textContent = 'Tidak dapat memutar video: ' + err.message; rec.stop(); return; }
      draw();
    }
    exportBtn.addEventListener('click', exportVideo);

    return () => {
      if (rec) rec.stop();
      cancelAnimationFrame(raf);
      player.pause();
      if (objUrl) URL.revokeObjectURL(objUrl);
      if (dlUrl) URL.revokeObjectURL(dlUrl);
    };
  }
});

/* ============================================================
   TEKS
   ============================================================ */
reg({
  id: 'word-counter', cat: 'Teks', icon: '🔢', title: 'Penghitung Kata',
  desc: 'Hitung kata, karakter, kalimat, paragraf, dan estimasi waktu baca.',
  render(root) {
    root.innerHTML = `<textarea class="input" placeholder="Tempel atau ketik teksmu di sini..."></textarea><div class="stats"></div>`;
    const ta = root.querySelector('textarea'), box = root.querySelector('.stats');
    const update = () => {
      const t = ta.value;
      const words = t.trim() ? t.trim().split(/\s+/).length : 0;
      const items = [
        ['Kata', fmtNum(words)],
        ['Karakter', fmtNum([...t].length)],
        ['Tanpa spasi', fmtNum(t.replace(/\s/g, '').length)],
        ['Kalimat', fmtNum(t.split(/[.!?]+/).filter(s => s.trim()).length)],
        ['Paragraf', fmtNum(t.split(/\n\s*\n/).filter(p => p.trim()).length)],
        ['Waktu baca', words ? Math.max(1, Math.ceil(words / 200)) + ' mnt' : '0 mnt']
      ];
      box.innerHTML = items.map(([k, v]) => `<div><small>${k}</small><b>${v}</b></div>`).join('');
    };
    ta.addEventListener('input', update);
    update();
  }
});

reg({
  id: 'text-case', cat: 'Teks', icon: '🔠', title: 'Konverter Huruf',
  desc: 'UPPERCASE, lowercase, Title Case, Sentence case, dan rapikan spasi.',
  render(root) {
    root.innerHTML = `
      <textarea class="input" placeholder="Tempel teks di sini..."></textarea>
      <div class="actions">
        <button class="btn sm secondary" data-m="upper">HURUF BESAR</button>
        <button class="btn sm secondary" data-m="lower">huruf kecil</button>
        <button class="btn sm secondary" data-m="title">Judul Kata</button>
        <button class="btn sm secondary" data-m="sentence">Kalimat</button>
        <button class="btn sm secondary" data-m="clean">Rapikan spasi</button>
      </div>
      <textarea class="input" readonly placeholder="Hasil akan muncul di sini..."></textarea>
      <div class="actions"><button class="btn" id="tcCopy">Salin hasil</button></div>`;
    const [src, out] = root.querySelectorAll('textarea');
    const T = {
      upper: t => t.toUpperCase(),
      lower: t => t.toLowerCase(),
      title: t => t.toLowerCase().replace(/(^|[\s"'(\[\-])(\p{L})/gu, (m, a, b) => a + b.toUpperCase()),
      sentence: t => t.toLowerCase().replace(/(^|[.!?]\s+)(\p{L})/gu, (m, a, b) => a + b.toUpperCase()),
      clean: t => t.replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim()
    };
    root.querySelectorAll('[data-m]').forEach(b => b.addEventListener('click', () => { out.value = T[b.dataset.m](src.value); }));
    root.querySelector('#tcCopy').addEventListener('click', e => copyText(out.value, e.currentTarget));
  }
});

reg({
  id: 'json-tools', cat: 'Teks', icon: '🧾', title: 'JSON Formatter',
  desc: 'Rapikan, kompres, dan validasi JSON langsung di browser.',
  render(root) {
    root.innerHTML = `
      <textarea class="input" placeholder='{"contoh": true}'></textarea>
      <div class="actions">
        <button class="btn" data-m="format">Format</button>
        <button class="btn secondary" data-m="minify">Minify</button>
        <button class="btn secondary" data-m="validate">Validasi</button>
      </div>
      <textarea class="input" readonly placeholder="Hasil..." style="margin-top:12px"></textarea>
      <div class="result hidden" id="jsonStatus"></div>`;
    const [src, out] = root.querySelectorAll('textarea');
    const status = root.querySelector('#jsonStatus');
    root.querySelectorAll('[data-m]').forEach(b => b.addEventListener('click', () => {
      status.classList.remove('hidden');
      try {
        const obj = JSON.parse(src.value);
        if (b.dataset.m === 'format') out.value = JSON.stringify(obj, null, 2);
        if (b.dataset.m === 'minify') out.value = JSON.stringify(obj);
        if (b.dataset.m === 'validate') out.value = '';
        status.innerHTML = '✅ JSON valid.';
      } catch (e) {
        out.value = '';
        status.innerHTML = `<span class="err">❌ ${esc(e.message)}</span>`;
      }
    }));
  }
});

reg({
  id: 'base64', cat: 'Teks', icon: '🧩', title: 'Base64 Encode / Decode',
  desc: 'Ubah teks ke Base64 dan sebaliknya, dengan dukungan UTF-8.',
  render(root) {
    const mode = select('Mode', [['enc', 'Encode (teks → Base64)'], ['dec', 'Decode (Base64 → teks)']], 'enc');
    root.append(mode);
    root.insertAdjacentHTML('beforeend', `
      <textarea class="input" id="bIn" placeholder="Teks atau Base64..." style="margin-top:12px"></textarea>
      <div class="actions"><button class="btn" id="bRun">Jalankan</button></div>
      <textarea class="input" id="bOut" readonly placeholder="Hasil..." style="margin-top:12px"></textarea>
      <div class="actions"><button class="btn secondary" id="bCopy">Salin hasil</button></div>
      <div class="result hidden" id="bErr"></div>`);
    const $ = s => root.querySelector(s);
    const encode = s => {
      const bytes = new TextEncoder().encode(s);
      let bin = ''; bytes.forEach(b => { bin += String.fromCharCode(b); });
      return btoa(bin);
    };
    const decode = s => {
      const bin = atob(s.trim().replace(/\s/g, ''));
      const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
      return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    };
    $('#bRun').addEventListener('click', () => {
      const err = $('#bErr');
      err.classList.add('hidden');
      try {
        $('#bOut').value = mode.select.value === 'enc' ? encode($('#bIn').value) : decode($('#bIn').value);
      } catch {
        $('#bOut').value = '';
        err.classList.remove('hidden');
        err.innerHTML = '<span class="err">❌ Input tidak valid untuk mode ini.</span>';
      }
    });
    $('#bCopy').addEventListener('click', e => copyText($('#bOut').value, e.currentTarget));
  }
});

/* ============================================================
   UTILITAS
   ============================================================ */
reg({
  id: 'qr-code', cat: 'Utilitas', icon: '📱', title: 'QR Code Generator',
  desc: 'Buat QR code dari teks atau tautan, dengan warna dan unduhan PNG.',
  render(root) {
    const QR_LIB = 'https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js';
    const ta = document.createElement('textarea');
    ta.className = 'input'; ta.rows = 3; ta.placeholder = 'Tulis teks atau tautan...';
    const size = select('Ukuran', [['256', '256 px'], ['512', '512 px'], ['1024', '1024 px']], '512');
    const fg = document.createElement('div'); fg.className = 'control';
    fg.innerHTML = '<label>Warna QR</label><input type="color" value="#0f172a">';
    const bg = document.createElement('div'); bg.className = 'control';
    bg.innerHTML = '<label>Latar</label><input type="color" value="#ffffff">';
    const grid = document.createElement('div'); grid.className = 'grid2';
    grid.append(size, fg, bg);
    const fgInput = fg.querySelector('input'), bgInput = bg.querySelector('input');

    const genBtn = mkBtn('Buat QR');
    const dlBtn = mkBtn('⬇ Unduh PNG', 'btn secondary'); dlBtn.disabled = true;
    const actions = document.createElement('div'); actions.className = 'actions'; actions.append(genBtn, dlBtn);
    const prev = document.createElement('div'); prev.className = 'preview';
    const status = document.createElement('div'); status.className = 'result';
    status.textContent = 'Masukkan teks lalu tekan Buat QR.';
    root.append(ta, grid, actions, prev, status);

    let canvas = null;
    async function make() {
      const text = ta.value.trim();
      if (!text) { status.textContent = 'Isi teks atau tautan terlebih dahulu.'; return; }
      genBtn.disabled = true;
      try {
        if (typeof qrcode !== 'function') await loadScript(QR_LIB);
        const qr = qrcode(0, 'M');
        qr.addData(text); qr.make();
        const n = qr.getModuleCount(), margin = 4;
        const cell = Math.max(1, Math.floor(Number(size.select.value) / (n + margin * 2)));
        canvas = document.createElement('canvas');
        canvas.width = canvas.height = (n + margin * 2) * cell;
        const cx = canvas.getContext('2d');
        cx.fillStyle = bgInput.value; cx.fillRect(0, 0, canvas.width, canvas.height);
        cx.fillStyle = fgInput.value;
        for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
          if (qr.isDark(r, c)) cx.fillRect((c + margin) * cell, (r + margin) * cell, cell, cell);
        }
        prev.innerHTML = ''; prev.append(canvas);
        dlBtn.disabled = false;
        status.textContent = `✅ QR dibuat • ${n} × ${n} modul • ${canvas.width} px`;
      } catch (e) {
        status.textContent = '❌ ' + e.message + ' (teks mungkin terlalu panjang)';
      } finally { genBtn.disabled = false; }
    }
    genBtn.addEventListener('click', make);
    dlBtn.addEventListener('click', () => { if (canvas) canvas.toBlob(b => saveBlob(b, 'ATHA-QR.png'), 'image/png'); });
  }
});

reg({
  id: 'password', cat: 'Utilitas', icon: '🔐', title: 'Generator Password',
  desc: 'Buat kata sandi acak yang kuat. Dibuat di browser, tidak dikirim ke server.',
  render(root) {
    const SETS = {
      besar: ['Huruf besar (A–Z)', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'],
      kecil: ['Huruf kecil (a–z)', 'abcdefghijklmnopqrstuvwxyz'],
      angka: ['Angka (0–9)', '0123456789'],
      simbol: ['Simbol (!@#…)', '!@#$%^&*()-_=+[]{};:,.<>?']
    };
    const rnd = n => { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] % n; };

    const len = slider('Panjang', 8, 64, 20, v => v + ' karakter', () => gen());
    const opts = document.createElement('div'); opts.className = 'grid2';
    opts.innerHTML = Object.entries(SETS).map(([k, [label]]) =>
      `<label class="check"><input type="checkbox" data-k="${k}" checked> ${esc(label)}</label>`).join('');
    const out = document.createElement('div'); out.className = 'pw';
    const info = document.createElement('div'); info.className = 'desc center';
    const row = document.createElement('div'); row.className = 'actions';
    const regen = mkBtn('🔄 Buat ulang');
    const copy = mkBtn('📋 Salin', 'btn secondary');
    row.append(regen, copy);
    root.append(len, opts, out, info, row);

    function gen() {
      const keys = [...opts.querySelectorAll('input:checked')].map(i => i.dataset.k);
      if (!keys.length) { out.textContent = 'Pilih minimal satu jenis karakter.'; info.textContent = ''; return; }
      const n = Number(len.input.value);
      const pool = keys.map(k => SETS[k][1]).join('');
      const chars = keys.map(k => SETS[k][1][rnd(SETS[k][1].length)]);
      while (chars.length < n) chars.push(pool[rnd(pool.length)]);
      for (let i = chars.length - 1; i > 0; i--) { const j = rnd(i + 1); [chars[i], chars[j]] = [chars[j], chars[i]]; }
      out.textContent = chars.join('');
      const bits = Math.round(n * Math.log2(pool.length));
      const level = bits < 40 ? 'Lemah' : bits < 60 ? 'Sedang' : bits < 80 ? 'Kuat' : 'Sangat kuat';
      info.textContent = `Kekuatan: ${level} (~${bits} bit)`;
    }
    opts.addEventListener('change', gen);
    regen.addEventListener('click', gen);
    copy.addEventListener('click', () => copyText(out.textContent, copy));
    gen();
  }
});

reg({
  id: 'color-tools', cat: 'Utilitas', icon: '🎨', title: 'Konverter Warna',
  desc: 'Ubah HEX ↔ RGB ↔ HSL dan buat palet warna dengan satu klik.',
  render(root) {
    const hexToRgb = h => { const m = /^#?([0-9a-f]{6})$/i.exec(h); if (!m) return null; const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
    const rgbToHex = ([r, g, b]) => '#' + [r, g, b].map(v => Math.round(v).toString(16).padStart(2, '0')).join('').toUpperCase();
    const rgbToHsl = ([r, g, b]) => {
      r /= 255; g /= 255; b /= 255;
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
      let h = 0, s = 0;
      if (mx !== mn) {
        const d = mx - mn;
        s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
        h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
        h *= 60;
      }
      return [Math.round(h), Math.round(s * 100), Math.round(l * 100)];
    };
    const mix = (rgb, target, t) => rgb.map((v, i) => v + (target[i] - v) * t);

    root.innerHTML = `
      <div class="grid2">
        <div class="control"><label>Pilih warna</label><input type="color" id="cPick" value="#7C3AED"></div>
        <div class="control"><label>HEX</label><input class="input sm" id="cHex" value="#7C3AED" maxlength="7"></div>
      </div>
      <div id="cRows"></div>
      <p class="desc" style="margin-top:18px">Palet (klik untuk menyalin)</p>
      <div class="swatches" id="cPal"></div>`;
    const $ = s => root.querySelector(s);

    function set(rgb) {
      const hex = rgbToHex(rgb), [h, s, l] = rgbToHsl(rgb);
      $('#cPick').value = hex.toLowerCase();
      if (document.activeElement !== $('#cHex')) $('#cHex').value = hex;
      $('#cRows').innerHTML = [
        ['HEX', hex],
        ['RGB', `rgb(${rgb.map(Math.round).join(', ')})`],
        ['HSL', `hsl(${h}, ${s}%, ${l}%)`]
      ].map(([k, v]) => `<div class="kv"><span>${k}</span><span><code>${esc(v)}</code> <button class="btn sm secondary" data-copy="${esc(v)}">Salin</button></span></div>`).join('');
      const palette = [
        mix(rgb, [255, 255, 255], 0.75), mix(rgb, [255, 255, 255], 0.4), rgb,
        mix(rgb, [0, 0, 0], 0.35), mix(rgb, [0, 0, 0], 0.7)
      ].map(rgbToHex);
      $('#cPal').innerHTML = palette.map(p => `<button class="swatch" data-copy="${p}" style="background:${p}">${p}</button>`).join('');
    }

    root.addEventListener('click', e => {
      const b = e.target.closest('[data-copy]');
      if (b) copyText(b.dataset.copy, b);
    });
    $('#cPick').addEventListener('input', e => set(hexToRgb(e.target.value)));
    $('#cHex').addEventListener('input', e => { const rgb = hexToRgb(e.target.value.trim()); if (rgb) set(rgb); });
    set([124, 58, 237]);
  }
});

reg({
  id: 'pomodoro', cat: 'Utilitas', icon: '⏱️', title: 'Pomodoro Timer',
  desc: 'Fokus 25 menit, istirahat 5 atau 15 menit, dan hitung sesi selesaimu.',
  render(root) {
    const MODES = {
      fokus: { label: 'Fokus', sec: 25 * 60 },
      istirahat: { label: 'Istirahat', sec: 5 * 60 },
      panjang: { label: 'Istirahat panjang', sec: 15 * 60 }
    };
    let mode = 'fokus', left = MODES.fokus.sec, timer = null, done = 0;

    root.innerHTML = `
      <div class="actions" id="pmModes"></div>
      <div class="big" id="pmTime"></div>
      <div class="actions"><button class="btn" id="pmToggle">▶ Mulai</button><button class="btn secondary" id="pmReset">Reset</button></div>
      <p class="desc center" id="pmInfo"></p>`;
    const $ = s => root.querySelector(s);

    Object.entries(MODES).forEach(([k, m]) => {
      const b = mkBtn(m.label, 'btn sm secondary');
      b.dataset.k = k;
      b.addEventListener('click', () => { stop(); mode = k; left = MODES[k].sec; paint(); });
      $('#pmModes').append(b);
    });

    function paint() {
      $('#pmTime').textContent = `${String(Math.floor(left / 60)).padStart(2, '0')}:${String(left % 60).padStart(2, '0')}`;
      $('#pmModes').querySelectorAll('button').forEach(b => b.classList.toggle('secondary', b.dataset.k !== mode));
      $('#pmInfo').textContent = `${MODES[mode].label} • Sesi fokus selesai hari ini: ${done}`;
    }
    function stop() {
      clearInterval(timer); timer = null;
      $('#pmToggle').textContent = '▶ Mulai';
    }
    function tick() {
      left--;
      if (left <= 0) {
        stop(); beep();
        if (mode === 'fokus') done++;
        left = MODES[mode].sec;
        $('#pmInfo').textContent = '⏰ Waktu habis! Pilih mode berikutnya.';
        paint();
        return;
      }
      paint();
    }

    $('#pmToggle').addEventListener('click', () => {
      if (timer) { stop(); return; }
      timer = setInterval(tick, 1000);
      $('#pmToggle').textContent = '⏸ Jeda';
    });
    $('#pmReset').addEventListener('click', () => { stop(); left = MODES[mode].sec; paint(); });
    paint();

    return () => { clearInterval(timer); };
  }
});
